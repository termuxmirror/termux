#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_URL_LENGTH 200

char *read_mirror_url(const char *filename) {
    char *url = NULL;
    char file_path[MAX_URL_LENGTH + 10]; // Add space for $HOME/.mirror/ and null terminator
    sprintf(file_path, "%s/.mirror/%s", getenv("HOME"), filename);

    FILE *file = fopen(file_path, "r");
    if (file != NULL) {
        url = (char *)malloc(MAX_URL_LENGTH * sizeof(char));
        if (url != NULL) {
            if (fgets(url, MAX_URL_LENGTH, file) == NULL) {
                free(url);
                url = NULL;
            } else {
                // Remove newline character if present
                size_t len = strlen(url);
                if (len > 0 && url[len - 1] == '\n')
                    url[len - 1] = '\0';
            }
        }
        fclose(file);
    }
    return url;
}

void install_file(const char *filename, const char *base_url) {
    char download_url[MAX_URL_LENGTH];
    sprintf(download_url, "%s%s%s", base_url, filename, ".sh");

    pid_t pid = fork();
    if (pid < 0) {
        perror("Fehler beim Forken");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        execlp("curl", "curl", "-o", filename, download_url, NULL);
        perror("Fehler beim Herunterladen der Datei");
        exit(EXIT_FAILURE);
    } else {
        wait(NULL);
        execlp("chmod", "chmod", "+x", filename, NULL);
        perror("Fehler beim Ändern der Berechtigungen");
        exit(EXIT_FAILURE);
    }
}

void search_file(const char *filename, const char *base_url) {
    char *mirror_url = read_mirror_url("mirror.txt");
    if (mirror_url == NULL) {
        fprintf(stderr, "Fehler: Konnte die Mirror-URL nicht auslesen.\n");
        exit(EXIT_FAILURE);
    }

    char search_url[MAX_URL_LENGTH];
    sprintf(search_url, "%s%s%s", mirror_url, filename, ".sh");
    free(mirror_url);

    pid_t pid = fork();
    if (pid < 0) {
        perror("Fehler beim Forken");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        execlp("curl", "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", search_url, NULL);
        perror("Fehler beim Suchen der Datei");
        exit(EXIT_FAILURE);
    } else {
        int status;
        wait(&status);
        if (WEXITSTATUS(status) == 0) {
            printf("Die Datei '%s' wurde auf der Webseite gefunden.\n", filename);
        } else {
            printf("Die Datei '%s' wurde nicht auf der Webseite gefunden.\n", filename);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Benutzung: %s {install|search} Dateiname\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *action = argv[1];
    const char *filename = argv[2];

    if (strcmp(action, "install") == 0) {
        const char *base_url = read_mirror_url("mirror.txt");
        if (base_url == NULL) {
            fprintf(stderr, "Fehler: Konnte die Mirror-URL nicht auslesen.\n");
            exit(EXIT_FAILURE);
        }
        install_file(filename, base_url);
        free((void *)base_url);
    } else if (strcmp(action, "search") == 0) {
        search_file(filename, "https://termuxmirror.netlify.app/mirror/");
    } else {
        printf("Ungültige Aktion: %s\n", action);
        printf("Benutzung: %s {install|search} Dateiname\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    return 0;
}
