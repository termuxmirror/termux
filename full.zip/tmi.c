#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_URL_LENGTH 200

char **read_mirror_urls(const char *filename, int *num_urls) {
    char **urls = NULL;
    char file_path[MAX_URL_LENGTH + 10]; // Add space for $HOME/.mirror/ and null terminator
    sprintf(file_path, "%s/.mirror/%s", getenv("HOME"), filename);

    FILE *file = fopen(file_path, "r");
    if (file != NULL) {
        char line[MAX_URL_LENGTH];
        int count = 0;
        while (fgets(line, sizeof(line), file) != NULL) {
            // Remove newline character if present
            size_t len = strlen(line);
            if (len > 0 && line[len - 1] == '\n')
                line[len - 1] = '\0';
            
            // Allocate memory for URL
            urls = (char **)realloc(urls, (count + 1) * sizeof(char *));
            urls[count] = strdup(line);
            count++;
        }
        *num_urls = count;
        fclose(file);
    }
    return urls;
}

void install_file(const char *filename, const char *base_url) {
    char download_url[MAX_URL_LENGTH];
    sprintf(download_url, "%s%s%s", base_url, filename, ".sh");

    pid_t pid = fork();
    if (pid < 0) {
        perror("Fehler beim Forken");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        execlp("curl", "curl", "-o", filename, download_url, NULL);
        perror("Fehler beim Herunterladen der Datei");
        exit(EXIT_FAILURE);
    } else {
        wait(NULL);
        execlp("chmod", "chmod", "+x", filename, NULL);
        perror("Fehler beim Ändern der Berechtigungen");
        exit(EXIT_FAILURE);
    }
}

void search_file(const char *filename, char **urls, int num_urls) {
    int found = 0;
    for (int i = 0; i < num_urls; i++) {
        char search_url[MAX_URL_LENGTH];
        sprintf(search_url, "%s%s%s", urls[i], filename, ".sh");

        pid_t pid = fork();
        if (pid < 0) {
            perror("Fehler beim Forken");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            execlp("curl", "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", search_url, NULL);
            perror("Fehler beim Suchen der Datei");
            exit(EXIT_FAILURE);
        } else {
            int status;
            wait(&status);
            if (WEXITSTATUS(status) == 0) {
                printf("Die Datei '%s' wurde auf der Webseite gefunden.\n", filename);
                found = 1;
                break;
            }
        }
    }
    if (!found) {
        printf("Die Datei '%s' wurde nicht auf der Webseite gefunden.\n", filename);
    }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Benutzung: %s {install|search} Dateiname\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *action = argv[1];
    const char *filename = argv[2];

    if (strcmp(action, "install") == 0) {
        int num_urls;
        char **urls = read_mirror_urls("mirror.txt", &num_urls);
        if (urls == NULL) {
            fprintf(stderr, "Fehler: Konnte die Mirror-URLs nicht auslesen.\n");
            exit(EXIT_FAILURE);
        }
        for (int i = 0; i < num_urls; i++) {
            install_file(filename, urls[i]);
        }
        for (int i = 0; i < num_urls; i++) {
            free(urls[i]);
        }
        free(urls);
    } else if (strcmp(action, "search") == 0) {
        int num_urls;
        char **urls = read_mirror_urls("mirror.txt", &num_urls);
        if (urls == NULL) {
            fprintf(stderr, "Fehler: Konnte die Mirror-URLs nicht auslesen.\n");
            exit(EXIT_FAILURE);
        }
        search_file(filename, urls, num_urls);
        for (int i = 0; i < num_urls; i++) {
            free(urls[i]);
        }
        free(urls);
    } else {
        printf("Ungültige Aktion: %s\n", action);
        printf("Benutzung: %s {install|search} Dateiname\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    return 0;
}
