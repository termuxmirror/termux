#!/bin/bash

gcc -o tmi tmi.c

mkdir .mirror

mv mirror.txt .mirror
