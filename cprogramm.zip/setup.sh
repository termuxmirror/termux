#!/bin/bash

gcc -o tmi tmi.c

echo 'alias tmi="$HOME/.programm/tmi"' >> $HOME/.bashrc

source $HOME/.bashrc

mkdir .programm

mv tmi .programm/

clear

echo "Run 'Source $HOME/.bashrc' then run tmi for installer and search"
