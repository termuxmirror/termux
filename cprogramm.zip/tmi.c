#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

void install_file(const char *filename, const char *base_url) {
    char download_url[200];
    sprintf(download_url, "%s%s%s", base_url, filename, ".sh");

    pid_t pid = fork();
    if (pid < 0) {
        perror("Fehler beim Forken");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        execlp("curl", "curl", "-o", filename, download_url, NULL);
        perror("Fehler beim Herunterladen der Datei");
        exit(EXIT_FAILURE);
    } else {
        wait(NULL);
        execlp("chmod", "chmod", "+x", filename, NULL);
        perror("Fehler beim Ändern der Berechtigungen");
        exit(EXIT_FAILURE);
    }
}

void search_file(const char *filename, const char *base_url) {
    char search_url[200];
    sprintf(search_url, "%s%s%s", base_url, filename, ".sh");

    pid_t pid = fork();
    if (pid < 0) {
        perror("Fehler beim Forken");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        execlp("curl", "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", search_url, NULL);
        perror("Fehler beim Suchen der Datei");
        exit(EXIT_FAILURE);
    } else {
        int status;
        wait(&status);
        if (WEXITSTATUS(status) == 0) {
            printf("Die Datei '%s' wurde auf der Webseite gefunden.\n", filename);
        } else {
            printf("Die Datei '%s' wurde nicht auf der Webseite gefunden.\n", filename);
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Benutzung: %s {install|search} Dateiname\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *action = argv[1];
    const char *filename = argv[2];
    const char *base_url = "https://termuxmirror.netlify.app/mirror/";

    if (strcmp(action, "install") == 0) {
        install_file(filename, base_url);
    } else if (strcmp(action, "search") == 0) {
        search_file(filename, base_url);
    } else {
        printf("Ungültige Aktion: %s\n", action);
        printf("Benutzung: %s {install|search} Dateiname\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    return 0;
}
