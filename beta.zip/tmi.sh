#!/bin/bash

# Überprüfen, ob mindestens zwei Parameter übergeben wurden
if [ $# -lt 2 ]; then
    echo "Benutzung: $0 {install|search} Dateiname"
    exit 1
fi

# Parameter zuordnen
action=$1
filename=$2

# Basis-URL für den Download/Search
base_url="https://termuxmirror.netlify.app/mirror/"

# Funktion, um eine Datei herunterzuladen und auszuführen
install_file() {
    # Überprüfen und ggfs. .sh Erweiterung hinzufügen
    if [[ $filename != *.sh ]]; then
        filename="$filename.sh"
    fi

    # Vollständige Download-URL
    download_url="$base_url$filename"

    # Datei herunterladen
    curl -o "$filename" "$download_url"

    # Überprüfen, ob die Datei erfolgreich heruntergeladen wurde
    if [ $? -ne 0 ]; then
        echo "Fehler beim Herunterladen der Datei."
        exit 1
    fi

    # Ausführrechte erteilen
    chmod +x "$filename"

    # Datei ausführen
    ./"$filename"

    # Datei löschen
    rm "$filename"
}

# Funktion, um die Verfügbarkeit einer Datei zu prüfen
search_file() {
    # .sh Erweiterung hinzufügen, falls nicht vorhanden
    if [[ $filename != *.sh ]]; then
        filename="$filename.sh"
    fi

    # Vollständige URL für die Suche
    search_url="$base_url$filename"

    # Prüfen, ob die Datei existiert
    status_code=$(curl -s -o /dev/null -w "%{http_code}" "$search_url")

    if [ "$status_code" -eq 200 ]; then
        echo "Die Datei '$filename' wurde auf der Webseite gefunden."
    else
        echo "Die Datei '$filename' wurde nicht auf der Webseite gefunden."
    fi
}

# Entscheiden, welche Aktion basierend auf dem ersten Parameter ausgeführt wird
case "$action" in
    install)
        install_file
        ;;
    search)
        search_file
        ;;
    *)
        echo "Ungültige Aktion: $action"
        echo "Benutzung: $0 {install|search} Dateiname"
        exit 1
        ;;
esac
