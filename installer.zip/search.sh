#!/bin/bash

# Check if the filename is provided as a parameter
if [ $# -eq 0 ]; then
    echo "Please provide the filename as a parameter."
    exit 1
fi

# Append .sh extension if not provided
filename="$1"
if [[ $filename != *.sh ]]; then
    filename="$filename.sh"
fi

# Base URL for the search
base_url="https://termuxmirror.netlify.app/mirror/"

# Construct the full URL for the search
search_url="$base_url$filename"

# Execute search request and display results
curl -s -o /dev/null -w "%{http_code}" "$search_url" | {
    read -r status_code
    if [ "$status_code" -eq 200 ]; then
        echo "The file '$filename' was found on the website."
    else
        echo "The file '$filename' was not found on the website."
    fi
}
