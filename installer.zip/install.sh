#!/bin/bash

# Überprüfen, ob der Dateiname als Parameter übergeben wurde
if [ $# -eq 0 ]; then
    echo "Bitte geben Sie den Dateinamen als Parameter an."
    exit 1
fi

# Überprüfen, ob die Dateierweiterung .sh fehlt und sie hinzufügen
filename=$1
if [[ $filename != *.sh ]]; then
    filename="$filename.sh"
fi

# Basis-URL für den Download
base_url="https://termuxmirror.netlify.app/mirror/"

# Die vollständige Download-URL aufbauen
download_url="$base_url$filename"

# Datei herunterladen
curl -o "$filename" "$download_url"

# Überprüfen, ob die Datei erfolgreich heruntergeladen wurde
if [ $? -ne 0 ]; then
    echo "Fehler beim Herunterladen der Datei."
    exit 1
fi

# Ausführrechte erteilen
chmod +x "$filename"

# Datei ausführen
./"$filename"

# Datei löschen
rm "$filename"
